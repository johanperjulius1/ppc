---
title: "LeoVegas"
logoObject:
  logoTitle: "LeoVegas"
  logoName: "leovegas-mobile.webp"
  backgroundColor: "orange"
  altText: "Leovegas casino"
rating: 5
excerpt: "100% bonus upp till 4000 kr + 100 free spins"
turnoverBonus: 35
turnoverFreespin: 10
positive1: "Bonus: 2500"
positive2: "300 free spin"
perks:
  perk1: "Free drinks"
  perk2: "VIP lounge access"
  perk3: "Exclusive bonuses"
  perk4: "Priority support"
  perk5: "Cashback offers"
  perk6: "Loyalty points"
badges:
  trustly: true
  swish: true
  bankId: false
  license: false
affiliateLink: "https://leovegas.se"
reviewLink: "/leovegas"
---
